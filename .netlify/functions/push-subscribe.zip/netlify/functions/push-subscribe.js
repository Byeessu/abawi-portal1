"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var push_subscribe_exports = {};
__export(push_subscribe_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(push_subscribe_exports);
var import_supabase_js = require("@supabase/supabase-js");
const supabaseUrl = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY;
const handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };
  }
  try {
    const { membreId, subscription, action = "subscribe" } = JSON.parse(event.body || "{}");
    if (!membreId || !subscription?.endpoint) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: "membreId and subscription.endpoint required" }) };
    }
    if (!supabaseUrl || !supabaseKey) {
      return { statusCode: 500, headers, body: JSON.stringify({ error: "Supabase env not configured" }) };
    }
    const supabase = (0, import_supabase_js.createClient)(supabaseUrl, supabaseKey);
    if (action === "unsubscribe") {
      await supabase.from("push_subscriptions").delete().eq("endpoint", subscription.endpoint);
      return { statusCode: 200, headers, body: JSON.stringify({ ok: true, action: "unsubscribed" }) };
    }
    const { error } = await supabase.from("push_subscriptions").upsert(
      {
        membre_id: membreId,
        endpoint: subscription.endpoint,
        p256dh: subscription.keys?.p256dh || null,
        auth: subscription.keys?.auth || null,
        user_agent: event.headers["user-agent"] || null,
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      },
      { onConflict: "endpoint" }
    );
    if (error) {
      return { statusCode: 500, headers, body: JSON.stringify({ error: error.message }) };
    }
    return { statusCode: 200, headers, body: JSON.stringify({ ok: true }) };
  } catch (e) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: e.message }) };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
