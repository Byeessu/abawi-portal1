"use strict";

// netlify/functions/logo-generator-advanced.js
async function callOpenAI(prompt, options = {}) {
  const apiKey = process.env.OPENAI_API_KEY || process.env.VITE_OPENAI_API_KEY || "";
  if (!apiKey) throw new Error("OPENAI_API_KEY missing");
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: options.model || "gpt-4o-mini",
      messages: [{ role: "user", content: prompt }],
      max_tokens: options.maxTokens || 2e3,
      temperature: options.temperature ?? 0.7,
      ...options.responseFormat ? { response_format: options.responseFormat } : {}
    })
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`OpenAI error ${res.status}: ${text.slice(0, 160)}`);
  }
  const data = await res.json();
  return data.choices?.[0]?.message?.content || "";
}
exports.handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const formData = JSON.parse(event.body);
    if (!formData.nomEntreprise || formData.nomEntreprise.trim().length === 0) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          error: "Le nom de l'entreprise est requis",
          code: "MISSING_COMPANY_NAME"
        })
      };
    }
    const prompt = buildAdvancedLogoPrompt(formData);
    const response = await callOpenAI(prompt, {
      maxTokens: 4e3,
      temperature: 0.9,
      model: "gpt-4-turbo-preview",
      responseFormat: { type: "json_object" }
    });
    const parsedResponse = parseAdvancedLogoResponse(response);
    const result = {
      success: true,
      logos: parsedResponse.logos.map((logo, index) => ({
        ...logo,
        id: index + 1,
        generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
        formData: {
          nomEntreprise: formData.nomEntreprise,
          stylePrefere: formData.stylePrefere,
          secteur: formData.secteur
        }
      }))
    };
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(result)
    };
  } catch (error) {
    console.error("Erreur g\xE9n\xE9ration logo avanc\xE9e:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: "Impossible de g\xE9n\xE9rer les logos. Veuillez r\xE9essayer.",
        code: "GENERATION_FAILED",
        details: process.env.NODE_ENV === "development" ? error.message : void 0
      })
    };
  }
};
function buildAdvancedLogoPrompt(formData) {
  const { nomEntreprise, slogan, secteur, valeurs, publicCible, stylePrefere, couleurPrimaire, couleurSecondaire } = formData;
  return [
    {
      role: "system",
      content: `Tu es un expert mondial en design graphique, branding et identit\xE9 visuelle. Tu travailles pour les plus grandes agences de design et tu as cr\xE9\xE9 des logos pour des marques Fortune 500.

Ta mission est de cr\xE9er 4 logos professionnels uniques et cr\xE9atifs bas\xE9s sur les informations fournies. Chaque logo doit \xEAtre une \u0153uvre d'art qui raconte une histoire et communique les valeurs de l'entreprise. // eslint-disable-line no-useless-escape

R\xC9PONSES EXIG\xC9ES:
- UNIQUEMENT un JSON valide
- Structure exacte: {"logos": [{"logo_data"}]}
- 4 objets logo dans le tableau "logos"

CHAMPS OBLIGATOIRES pour chaque logo:
- id: num\xE9ro unique (1-4)
- name: nom exact de l'entreprise // eslint-disable-line no-useless-escape
- style: style principal (modern, classic, tech, eco, bold, playful, luxury, minimalist)
- primaryColor: couleur hexad\xE9cimale principale
- secondaryColor: couleur hexad\xE9cimale secondaire
- tertiaryColor: couleur hexad\xE9cimale tertiaire (optionnel)
- icon: emoji ou symbole repr\xE9sentatif
- preview: texte/abr\xE9viation pour le logo (2-4 caract\xE8res max)
- description: description cr\xE9ative du concept (20-50 mots)
- fontCategory: cat\xE9gorie de typographie (serif, sans-serif, display, handwritten, monospace)
- layout: disposition (horizontal, vertical, emblem, combination, abstract, geometric)
- visualElements: \xE9l\xE9ments visuels cl\xE9s (ex: montagnes stylis\xE9es, cercles entrelac\xE9s)
- symbolism: symbolisme et signification (ex: croissance et innovation)
- targetPersonality: personnalit\xE9 cible du logo (ex: confiant, moderne, accessible)
- scalability: adaptation \xE0 diff\xE9rentes tailles (ex: excellent, lisible \xE0 8px)
- uniquenessScore: score d'unicit\xE9 (1-10)
- marketFit: ad\xE9quation au march\xE9 (ex: parfait pour secteur tech)

CRIT\xC8RES DE QUALIT\xC9:
- Cr\xE9ativit\xE9 et originalit\xE9 maximales
- Coh\xE9rence avec l'identit\xE9 de marque
- Adaptabilit\xE9 multi-supports
- M\xE9morabilit\xE9 et impact visuel
- Pertinence sectorielle`
    },
    {
      role: "user",
      content: `CR\xC9ATION DE LOGOS AVANC\xC9S

ENTREPRISE: "${nomEntreprise || "Entreprise"}"
SLOGAN: "${slogan || "Non sp\xE9cifi\xE9"}"
SECTEUR: ${secteur || "Non sp\xE9cifi\xE9"}
VALEURS: ${valeurs || "Non sp\xE9cifi\xE9"}
PUBLIC CIBLE: ${publicCible || "Non sp\xE9cifi\xE9"}

PR\xC9F\xC9RENCES CR\xC9ATIVES:
- Style principal: ${stylePrefere || "modern"}
- Couleur primaire: ${couleurPrimaire || "#1E40AF"}
- Couleur secondaire: ${couleurSecondaire || "#DC2626"}

DIRECTIVES CR\xC9ATIVES:
1. G\xE9n\xE8re 4 logos uniques mais coh\xE9rents
2. Chaque logo doit explorer une facette diff\xE9rente de l'identit\xE9
3. Int\xE8gre les couleurs de mani\xE8re cr\xE9ative et \xE9quilibr\xE9e
4. Les ic\xF4nes doivent \xEAtre m\xE9morables et pertinentes
5. Les previews doivent \xEAtre imm\xE9diatement reconnaissables
6. Les descriptions doivent inspirer et convaincre
7. Pense \xE0 l'adaptation sur tous les supports (web, print, mobile)
8. Consid\xE8re la concurrence et le positionnement unique

INSPIRATION SECTORIELLE:
${getSectorInspiration(secteur)}

FORMAT JSON EXACT:
{
  "logos": [
    {
      "id": 1,
      "name": "NomEntreprise",
      "style": "modern",
      "primaryColor": "#1E40AF",
      "secondaryColor": "#DC2626",
      "tertiaryColor": "#F59E0B",
      "icon": "\u{1F680}",
      "preview": "NE",
      "description": "Design moderne \xE9pur\xE9 avec lignes dynamiques",
      "fontCategory": "sans-serif",
      "layout": "horizontal",
      "visualElements": "fl\xE8ches ascendantes, cercles",
      "symbolism": "croissance et innovation",
      "targetPersonality": "confiant, avant-gardiste",
      "scalability": "excellent",
      "uniquenessScore": 8,
      "marketFit": "parfait pour secteur tech"
    }
  ]
}`
    }
  ];
}
function getSectorInspiration(secteur) {
  const inspirations = {
    "tech": "Pense \xE0 Silicon Valley, innovation, disruption, futur, code, circuits, connectivity. Utilise des \xE9l\xE9ments g\xE9om\xE9triques, lignes \xE9pur\xE9es, gradients modernes.",
    "finance": "Pense \xE0 confiance, s\xE9curit\xE9, croissance, stabilit\xE9, or, argent. Utilise des symboles classiques, typographies serif, couleurs professionnelles.",
    "sante": "Pense \xE0 vie, soin, nature, gu\xE9rison, espoir. Utilise des formes organiques, couleurs apaisantes, symboles m\xE9dicaux modernis\xE9s.",
    "education": "Pense \xE0 savoir, croissance, livres, lumi\xE8re, avenir. Utilise des symboles de connaissance, couleurs inspirantes, typographies claires.",
    "retail": "Pense \xE0 shopping, exp\xE9rience, qualit\xE9, tendance. Utilise des formes dynamiques, couleurs attractives, symboles de consommation.",
    "consulting": "Pense \xE0 expertise, strat\xE9gie, solutions, excellence. Utilise des formes structur\xE9es, couleurs professionnelles, symboles d'intelligence.",
    "immobilier": "Pense \xE0 maison, investissement, s\xE9curit\xE9, lieu. Utilise des formes architecturales, couleurs terrestres, symboles de propri\xE9t\xE9.",
    "restaurant": "Pense \xE0 go\xFBt, exp\xE9rience, ambiance, qualit\xE9. Utilise des formes organiques, couleurs app\xE9tissantes, symboles culinaires."
  };
  return inspirations[secteur] || "Pense \xE0 professionnalisme, qualit\xE9, service client. Utilise des designs \xE9quilibr\xE9s et professionnels.";
}
function parseAdvancedLogoResponse(response) {
  try {
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error("Format de r\xE9ponse invalide");
    }
    const parsed = JSON.parse(jsonMatch[0]);
    if (!parsed.logos || !Array.isArray(parsed.logos)) {
      throw new Error("Structure de r\xE9ponse invalide");
    }
    if (parsed.logos.length !== 4) {
      throw new Error("Nombre de logos incorrect");
    }
    parsed.logos.forEach((logo, index) => {
      const requiredFields = ["name", "style", "primaryColor", "secondaryColor", "icon", "preview", "description"];
      const missingFields = requiredFields.filter((field) => !logo[field]);
      if (missingFields.length > 0) {
        throw new Error(`Logo ${index + 1}: champs manquants: ${missingFields.join(", ")}`);
      }
      if (!isValidColor(logo.primaryColor) || !isValidColor(logo.secondaryColor)) {
        throw new Error(`Logo ${index + 1}: couleurs invalides`);
      }
      if (logo.uniquenessScore && (logo.uniquenessScore < 1 || logo.uniquenessScore > 10)) {
        logo.uniquenessScore = Math.min(10, Math.max(1, logo.uniquenessScore));
      }
    });
    return parsed;
  } catch (error) {
    console.error("Erreur parsing logo response avanc\xE9e:", error);
    return {
      logos: generateAdvancedDefaultLogos()
    };
  }
}
function isValidColor(color) {
  return /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/.test(color);
}
function generateAdvancedDefaultLogos() {
  return [
    {
      id: 1,
      name: "LOGO",
      style: "modern",
      primaryColor: "#1E40AF",
      secondaryColor: "#DC2626",
      tertiaryColor: "#F59E0B",
      icon: "\u{1F680}",
      preview: "LO",
      description: "Design moderne \xE9pur\xE9 avec lignes dynamiques",
      fontCategory: "sans-serif",
      layout: "horizontal",
      visualElements: "fl\xE8ches ascendantes, cercles",
      symbolism: "croissance et innovation",
      targetPersonality: "confiant, avant-gardiste",
      scalability: "excellent",
      uniquenessScore: 8,
      marketFit: "parfait pour secteur tech"
    },
    {
      id: 2,
      name: "LOGO",
      style: "luxury",
      primaryColor: "#DC2626",
      secondaryColor: "#1E40AF",
      tertiaryColor: "#FFFFFF",
      icon: "\u26A1",
      preview: "LOG",
      description: "Design luxueux avec \xE9l\xE9gance intemporelle",
      fontCategory: "serif",
      layout: "emblem",
      visualElements: "sceaux, ornements",
      symbolism: "excellence et prestige",
      targetPersonality: "sophistiqu\xE9, exclusif",
      scalability: "tr\xE8s bon",
      uniquenessScore: 9,
      marketFit: "luxe et premium"
    },
    {
      id: 3,
      name: "LOGO",
      style: "minimalist",
      primaryColor: "#1E40AF",
      secondaryColor: "#FFFFFF",
      tertiaryColor: "#E5E7EB",
      icon: "\u{1F3C6}",
      preview: "L",
      description: "Design minimaliste avec impact maximal",
      fontCategory: "sans-serif",
      layout: "vertical",
      visualElements: "lignes \xE9pur\xE9es, espaces n\xE9gatifs",
      symbolism: "simplicit\xE9 et clart\xE9",
      targetPersonality: "moderne, accessible",
      scalability: "parfait",
      uniquenessScore: 7,
      marketFit: "moderne et \xE9pur\xE9"
    },
    {
      id: 4,
      name: "LOGO",
      style: "tech",
      primaryColor: "#DC2626",
      secondaryColor: "#000000",
      tertiaryColor: "#00FF00",
      icon: "\u{1F48E}",
      preview: "LO",
      description: "Design technologique futuriste",
      fontCategory: "monospace",
      layout: "geometric",
      visualElements: "circuits, pixels, hexagones",
      symbolism: "innovation et technologie",
      targetPersonality: "innovant, technique",
      scalability: "excellent",
      uniquenessScore: 9,
      marketFit: "tech et gaming"
    }
  ];
}
