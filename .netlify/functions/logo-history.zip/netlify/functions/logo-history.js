"use strict";

// netlify/functions/logo-history.js
var logoHistoryDB = /* @__PURE__ */ new Map();
exports.handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, DELETE, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers
    };
  }
  try {
    const userId = extractUserId(event);
    if (!userId) {
      return {
        statusCode: 401,
        headers,
        body: JSON.stringify({
          error: "Utilisateur non authentifi\xE9",
          code: "UNAUTHORIZED"
        })
      };
    }
    const path = event.path.replace(/\.netlify\/functions\/logo-history\/?/, "");
    const method = event.httpMethod;
    if (method === "GET" && !path) {
      return await getLogoHistory(userId, headers);
    } else if (method === "POST" && !path) {
      return await saveLogoToHistory(userId, JSON.parse(event.body), headers);
    } else if (method === "DELETE" && path) {
      const logoId = path.split("/")[0];
      return await deleteLogoFromHistory(userId, logoId, headers);
    } else {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({
          error: "Endpoint non trouv\xE9",
          code: "NOT_FOUND"
        })
      };
    }
  } catch (error) {
    console.error("Erreur logo-history:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Erreur serveur",
        code: "SERVER_ERROR",
        details: process.env.NODE_ENV === "development" ? error.message : void 0
      })
    };
  }
};
function extractUserId(event) {
  const authHeader = event.headers.authorization || event.headers.Authorization;
  if (authHeader) {
    try {
      const token = authHeader.replace("Bearer ", "");
      const payload = JSON.parse(atob(token.split(".")[1]));
      return payload.userId || payload.sub;
    } catch (e) {
      console.warn("Token invalide:", e);
    }
  }
  const sessionHeader = event.headers["x-session-id"] || event.headers["X-Session-ID"];
  if (sessionHeader) {
    return `session_${sessionHeader}`;
  }
  const clientIP = event.headers["client-ip"] || event.headers["x-forwarded-for"] || "anonymous";
  return `ip_${clientIP.split(",")[0].trim()}`;
}
async function getLogoHistory(userId, headers) {
  try {
    const userHistory = logoHistoryDB.get(userId) || [];
    const sortedHistory = userHistory.sort(
      (a, b) => new Date(b.createdAt) - new Date(a.createdAt)
    );
    const limitedHistory = sortedHistory.slice(0, 50);
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        logos: limitedHistory,
        total: userHistory.length
      })
    };
  } catch (error) {
    console.error("Erreur r\xE9cup\xE9ration historique:", error);
    throw error;
  }
}
async function saveLogoToHistory(userId, logoData, headers) {
  try {
    if (!logoData.name || !logoData.style) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          error: "Donn\xE9es du logo invalides",
          code: "INVALID_LOGO_DATA"
        })
      };
    }
    const userHistory = logoHistoryDB.get(userId) || [];
    const newLogo = {
      id: generateLogoId(),
      ...logoData,
      userId,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    userHistory.unshift(newLogo);
    const limitedHistory = userHistory.slice(0, 100);
    logoHistoryDB.set(userId, limitedHistory);
    return {
      statusCode: 201,
      headers,
      body: JSON.stringify({
        success: true,
        logo: newLogo,
        message: "Logo sauvegard\xE9 avec succ\xE8s"
      })
    };
  } catch (error) {
    console.error("Erreur sauvegarde logo:", error);
    throw error;
  }
}
async function deleteLogoFromHistory(userId, logoId, headers) {
  try {
    const userHistory = logoHistoryDB.get(userId) || [];
    const initialLength = userHistory.length;
    const filteredHistory = userHistory.filter((logo) => logo.id !== logoId);
    if (filteredHistory.length === initialLength) {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({
          error: "Logo non trouv\xE9",
          code: "LOGO_NOT_FOUND"
        })
      };
    }
    logoHistoryDB.set(userId, filteredHistory);
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        message: "Logo supprim\xE9 avec succ\xE8s"
      })
    };
  } catch (error) {
    console.error("Erreur suppression logo:", error);
    throw error;
  }
}
function generateLogoId() {
  return `logo_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}
