"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/lib/runtimeApiKeys.js
function readStoredApiKeys() {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(API_KEYS_STORAGE) || "{}";
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}
function firstNonEmpty(values = []) {
  for (const value of values) {
    if (typeof value === "string" && value.trim()) return value.trim();
  }
  return "";
}
function getStoredProviderKeys(providerId) {
  const stored = readStoredApiKeys();
  const node = stored?.[providerId];
  if (!node || typeof node !== "object") {
    return { key: "", alias: "" };
  }
  return {
    key: typeof node.key_value === "string" ? node.key_value.trim() : "",
    alias: typeof node.key_alias_value === "string" ? node.key_alias_value.trim() : ""
  };
}
function resolveRuntimeApiKey({
  envKeys = (
    /** @type {string[]} */
    []
  ),
  providerId = "",
  includeAlias = true
} = {}) {
  const provider = providerId ? getStoredProviderKeys(providerId) : { key: "", alias: "" };
  const storedValues = includeAlias ? [provider.key, provider.alias] : [provider.key];
  return firstNonEmpty([...envKeys, ...storedValues]);
}
var API_KEYS_STORAGE;
var init_runtimeApiKeys = __esm({
  "src/lib/runtimeApiKeys.js"() {
    "use strict";
    API_KEYS_STORAGE = "abawi_api_keys_v2";
  }
});

// src/lib/groqClient.js
var groqClient_exports = {};
__export(groqClient_exports, {
  callGroq: () => callGroq,
  callGroqJSON: () => callGroqJSON,
  getProviderInfo: () => getProviderInfo,
  groqChatCompletion: () => groqChatCompletion,
  hasGroqAccess: () => hasGroqAccess
});
function isMaskedValue(v) {
  if (!v || typeof v !== "string") return true;
  return /\*{4,}/.test(v) || v.trim() === "" || PLACEHOLDERS.has(v.trim().toLowerCase());
}
function safeEnv(value, fallback) {
  return isMaskedValue(value) ? fallback : value;
}
function normalizeModelId(value, fallback = DEFAULT_GROQ_MODEL) {
  if (!value || typeof value !== "string") return fallback;
  let model = value.trim();
  if (!model) return fallback;
  model = model.replace(/\s*-\s*/g, "-");
  model = model.replace(/^models\//i, "");
  return model || fallback;
}
function resolveProvider(key) {
  if (!key) return { baseUrl: DEFAULT_GROQ_BASE_URL, model: DEFAULT_GROQ_MODEL };
  if (key.startsWith("AIzaSy")) {
    return {
      baseUrl: "https://generativelanguage.googleapis.com/v1beta/openai",
      model: normalizeModelId(safeEnv(import_meta.env.VITE_GEMINI_MODEL, "gemini-2.0-flash"), "gemini-2.0-flash")
    };
  }
  if (key.startsWith("xai-")) {
    return {
      baseUrl: "https://api.x.ai/v1",
      model: "grok-3"
    };
  }
  return {
    baseUrl: safeEnv(import_meta.env.VITE_GROQ_BASE_URL, DEFAULT_GROQ_BASE_URL),
    model: normalizeModelId(safeEnv(import_meta.env.VITE_GROQ_MODEL, DEFAULT_GROQ_MODEL))
  };
}
function getGroqBrowserKey() {
  return resolveRuntimeApiKey({
    envKeys: [
      safeEnv(import_meta.env.VITE_GROQ_API_KEY, ""),
      safeEnv(import_meta.env.GROQ_API_KEY, ""),
      safeEnv(import_meta.env.VITE_GROK_LLAMA_API_KEY, ""),
      safeEnv(import_meta.env.GROK_LLAMA_API_KEY, "")
    ].filter(Boolean),
    providerId: "groq",
    includeAlias: true
  });
}
function normalizeError(status, text = "") {
  const upperText = String(text || "").toUpperCase();
  if (status === 401 || status === 403) {
    return new Error("Cl\xE9 API invalide. V\xE9rifiez la variable d\u2019environnement GROQ_API_KEY (ou VITE_GROQ_API_KEY / VITE_GROK_LLAMA_API_KEY) dans le dashboard Netlify, ou ajoutez une cl\xE9 valide dans Param\xE8tres > Cl\xE9s API.");
  }
  if (status === 429) return new Error("RATE_LIMIT");
  if (status === 413) return new Error("REQUEST_TOO_LARGE");
  if (status === 400 && (upperText.includes("CONTEXT_LENGTH") || upperText.includes("TOO_LARGE") || upperText.includes("TOO LARGE") || upperText.includes("REDUCE THE LENGTH") || upperText.includes("TOKENS_LIMIT") || upperText.includes("MAXIMUM CONTEXT") || upperText.includes("CONTEXT WINDOW") || upperText.includes("MAX_TOKENS"))) return new Error("REQUEST_TOO_LARGE");
  if (status === 400 && (upperText.includes("RATE_LIMIT") || upperText.includes("RATE LIMIT") || upperText.includes("TOO MANY"))) return new Error("RATE_LIMIT");
  if (status === 404 && (upperText.includes("MODEL") || upperText.includes("MODELS/"))) return new Error("MODEL_NOT_FOUND");
  if (status === 500 && upperText.includes("NOT CONFIGURED")) return new Error("NO_KEY");
  if (status >= 500) return new Error("GROQ_UPSTREAM_ERROR");
  if (status === 400 && (upperText.includes("REQUIRED WORD") || upperText.includes("TOOL_USE_FAILED") || upperText.includes("MESSAGES REQUIRED") || upperText.includes("JSON_MODE") || upperText.includes("REQUIRES THE WORD") || upperText.includes("RESPONSE_FORMAT"))) return new Error("INVALID_PROMPT");
  if (status === 400) return new Error(`HTTP_400:${text ? text.slice(0, 120) : ""}`);
  return new Error(`HTTP_${status}${text ? `:${text.slice(0, 80)}` : ""}`);
}
async function withRetry(fn, attempts = 3) {
  let lastErr;
  for (let i = 0; i < attempts; i++) {
    try {
      return await fn();
    } catch (e) {
      lastErr = e;
      const code = String(e?.message || "");
      const transient = code.includes("RATE_LIMIT") || code.includes("UPSTREAM_ERROR") || code.includes("HTTP_5") || code.startsWith("HTTP_400");
      if (!transient || i === attempts - 1) break;
      await new Promise((r) => setTimeout(r, 1500 * (i + 1)));
    }
  }
  throw lastErr;
}
function normalizePayloadModel(payload, fallbackModel) {
  return {
    ...payload,
    model: normalizeModelId(payload?.model, fallbackModel)
  };
}
function isModel404(error) {
  const code = String(error?.message || "").toUpperCase();
  return code.includes("MODEL_NOT_FOUND") || code.includes("HTTP_404") && (code.includes("MODEL") || code.includes("MODELS/"));
}
function isRateLimited(error) {
  return String(error?.message || "").toUpperCase().includes("RATE_LIMIT");
}
function getProviderFallbackModels(baseUrl, baseModel) {
  const normalizedBaseUrl = String(baseUrl || "").toLowerCase();
  if (normalizedBaseUrl.includes("api.groq.com")) {
    return [baseModel, ...GROQ_MODEL_FALLBACKS];
  }
  return [baseModel];
}
async function tryWithRateLimitFallback(payload, requestFn, fallbackModels = []) {
  const triedModels = /* @__PURE__ */ new Set();
  const modelCandidates = fallbackModels.length ? fallbackModels : [normalizeModelId(payload?.model, DEFAULT_GROQ_MODEL)];
  let lastError = null;
  for (const model of modelCandidates) {
    const normalizedModel = normalizeModelId(model, DEFAULT_GROQ_MODEL);
    if (triedModels.has(normalizedModel)) continue;
    triedModels.add(normalizedModel);
    try {
      const candidatePayload = normalizePayloadModel({ ...payload, model: normalizedModel }, normalizedModel);
      return await requestFn(candidatePayload);
    } catch (error) {
      lastError = error;
      if (!isRateLimited(error)) throw error;
    }
  }
  throw lastError || new Error("RATE_LIMIT");
}
async function callProxy(payload) {
  const base = typeof window !== "undefined" ? window.location.origin : "";
  const res = await fetch(`${base}/.netlify/functions/groq-chat?t=${Date.now()}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
    cache: "no-store"
  });
  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw normalizeError(res.status, txt);
  }
  return await res.json();
}
async function callDirect(payload, apiKey, baseUrl) {
  const url = `${baseUrl || DEFAULT_GROQ_BASE_URL}/chat/completions`;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });
  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw normalizeError(res.status, txt);
  }
  return await res.json();
}
async function groqChatCompletion(payload, preferredKey = "") {
  const key = preferredKey || getGroqBrowserKey() || "";
  const { baseUrl, model: resolvedModel } = resolveProvider(key);
  const normalizedPayload = normalizePayloadModel(payload, resolvedModel);
  const fallbackModels = getProviderFallbackModels(baseUrl, resolvedModel);
  if (key) {
    try {
      return await tryWithRateLimitFallback(
        normalizedPayload,
        (candidatePayload) => withRetry(() => callDirect(candidatePayload, key, baseUrl)),
        fallbackModels
      );
    } catch (error) {
      if (isModel404(error)) {
        const fallbackPayload = normalizePayloadModel({ ...normalizedPayload, model: resolvedModel }, resolvedModel);
        try {
          return await tryWithRateLimitFallback(
            fallbackPayload,
            (candidatePayload) => withRetry(() => callDirect(candidatePayload, key, baseUrl)),
            fallbackModels
          );
        } catch {
        }
      }
      try {
        return await tryWithRateLimitFallback(
          normalizedPayload,
          (candidatePayload) => withRetry(() => callProxy(candidatePayload)),
          fallbackModels
        );
      } catch {
        throw error;
      }
    }
  }
  try {
    return await tryWithRateLimitFallback(
      normalizedPayload,
      (candidatePayload) => withRetry(() => callProxy(candidatePayload)),
      fallbackModels
    );
  } catch (error) {
    if (isModel404(error)) {
      const fallbackPayload = normalizePayloadModel({ ...normalizedPayload, model: resolvedModel }, resolvedModel);
      return await tryWithRateLimitFallback(
        fallbackPayload,
        (candidatePayload) => withRetry(() => callProxy(candidatePayload)),
        fallbackModels
      );
    }
    throw error;
  }
}
function hasGroqAccess() {
  return true;
}
function getProviderInfo() {
  const key = getGroqBrowserKey();
  const { baseUrl, model } = resolveProvider(key);
  return { baseUrl, model, key };
}
async function callGroq(promptOrMessages, options = {}) {
  const { model: resolvedModel } = resolveProvider(getGroqBrowserKey());
  const {
    maxTokens = 1500,
    temperature = 0.7,
    model = resolvedModel,
    jsonMode = false,
    system
  } = options;
  const messages = typeof promptOrMessages === "string" ? system ? [{ role: "system", content: system }, { role: "user", content: promptOrMessages }] : [{ role: "user", content: promptOrMessages }] : promptOrMessages;
  const payload = {
    model,
    messages,
    max_tokens: maxTokens,
    temperature,
    ...jsonMode ? { response_format: { type: "json_object" } } : {}
  };
  const data = await groqChatCompletion(payload);
  return data.choices?.[0]?.message?.content?.trim() || "";
}
async function callGroqJSON(promptOrMessages, options = {}) {
  const raw = await callGroq(promptOrMessages, { ...options, jsonMode: true, temperature: options.temperature ?? 0.1 });
  try {
    return JSON.parse(raw);
  } catch {
    const match = raw.match(/[{[][\s\S]*[}\]]/);
    if (match) {
      try {
        return JSON.parse(match[0]);
      } catch {
      }
    }
    return null;
  }
}
var import_meta, DEFAULT_GROQ_BASE_URL, DEFAULT_GROQ_MODEL, GROQ_MODEL_FALLBACKS, PLACEHOLDERS;
var init_groqClient = __esm({
  "src/lib/groqClient.js"() {
    "use strict";
    init_runtimeApiKeys();
    import_meta = {};
    DEFAULT_GROQ_BASE_URL = "https://api.groq.com/openai/v1";
    DEFAULT_GROQ_MODEL = "llama-3.3-70b-versatile";
    GROQ_MODEL_FALLBACKS = ["llama-3.1-8b-instant", "gemma2-9b-it"];
    PLACEHOLDERS = /* @__PURE__ */ new Set(["undefined", "null", "", "your_key_here", "xxx", "***", "sk-", "gsk-"]);
  }
});

// netlify/functions/logo-generator.js
var { callGroq: callGroq2 } = (init_groqClient(), __toCommonJS(groqClient_exports));
exports.handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const formData = JSON.parse(event.body);
    if (!formData.nomEntreprise || formData.nomEntreprise.trim().length === 0) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          error: "Le nom de l'entreprise est requis",
          code: "MISSING_COMPANY_NAME"
        })
      };
    }
    const prompt = buildLogoPrompt(formData);
    const response = await callGroq2(
      [
        {
          role: "system",
          content: `Tu es un expert en design graphique et branding. G\xE9n\xE8re des logos professionnels uniques bas\xE9s sur les informations fournies. 
          
          R\xE9ponds UNIQUEMENT avec un JSON valide contenant un tableau "logos" avec 4 objets logo.
          
          Chaque objet logo doit contenir:
          - id: num\xE9ro unique (1-4)
          - name: nom de l'entreprise
          - style: style du logo (modern, classic, tech, eco, bold, playful)
          - primaryColor: couleur hexad\xE9cimale
          - secondaryColor: couleur hexad\xE9cimale
          - icon: emoji repr\xE9sentatif
          - preview: texte/abr\xE9viation pour le logo (2-3 caract\xE8res max)
          - description: br\xE8ve description du design
          - fontCategory: cat\xE9gorie de typographie (serif, sans-serif, display, handwritten)
          - layout: disposition du logo (horizontal, vertical, emblem, combination)
          
          Les logos doivent \xEAtre coh\xE9rents avec l'identit\xE9 de marque demand\xE9e.`
        },
        {
          role: "user",
          content: prompt
        }
      ],
      {
        maxTokens: 2e3,
        temperature: 0.8,
        jsonMode: true
      }
    );
    const parsedResponse = parseLogoResponse(response);
    const result = {
      success: true,
      logos: parsedResponse.logos.map((logo, index) => ({
        ...logo,
        id: index + 1,
        generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
        formData: {
          nomEntreprise: formData.nomEntreprise,
          stylePrefere: formData.stylePrefere,
          secteur: formData.secteur
        }
      }))
    };
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(result)
    };
  } catch (error) {
    console.error("Erreur g\xE9n\xE9ration logo IA:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: "Impossible de g\xE9n\xE9rer les logos. Veuillez r\xE9essayer.",
        code: "GENERATION_FAILED",
        details: process.env.NODE_ENV === "development" ? error.message : void 0
      })
    };
  }
};
function buildLogoPrompt(formData) {
  const { nomEntreprise, slogan, secteur, valeurs, publicCible, stylePrefere, couleurPrimaire, couleurSecondaire } = formData;
  return `
G\xE9n\xE8re 4 logos professionnels pour: "${nomEntreprise || "Entreprise"}"

INFORMATIONS ENTREPRISE:
- Nom: ${nomEntreprise || "Non sp\xE9cifi\xE9"}
- Slogan: ${slogan || "Non sp\xE9cifi\xE9"}
- Secteur: ${secteur || "Non sp\xE9cifi\xE9"}
- Valeurs: ${valeurs || "Non sp\xE9cifi\xE9"}
- Public cible: ${publicCible || "Non sp\xE9cifi\xE9"}

PR\xC9F\xC9RENCES DESIGN:
- Style principal: ${stylePrefere || "modern"}
- Couleur primaire: ${couleurPrimaire || "#1E40AF"}
- Couleur secondaire: ${couleurSecondaire || "#DC2626"}

CONSIGNES:
1. Cr\xE9e 4 variations uniques mais coh\xE9rentes
2. Chaque logo doit utiliser le style demand\xE9 comme inspiration principale
3. Int\xE8gre intelligemment les couleurs sp\xE9cifi\xE9es
4. Les ic\xF4nes doivent \xEAtre pertinentes pour le secteur
5. Les previews doivent \xEAtre des abr\xE9viations reconnaissables
6. Les descriptions doivent expliquer le concept cr\xE9atif

FORMAT DE R\xC9PONSE JSON EXIG\xC9:
{
  "logos": [
    {
      "id": 1,
      "name": "NomEntreprise",
      "style": "modern",
      "primaryColor": "#1E40AF",
      "secondaryColor": "#DC2626",
      "icon": "\u{1F680}",
      "preview": "NE",
      "description": "Design moderne avec lignes \xE9pur\xE9es",
      "fontCategory": "sans-serif",
      "layout": "horizontal"
    }
  ]
}
`;
}
function parseLogoResponse(response) {
  try {
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error("Format de r\xE9ponse invalide");
    }
    const parsed = JSON.parse(jsonMatch[0]);
    if (!parsed.logos || !Array.isArray(parsed.logos)) {
      throw new Error("Structure de r\xE9ponse invalide");
    }
    if (parsed.logos.length !== 4) {
      throw new Error("Nombre de logos incorrect");
    }
    parsed.logos.forEach((logo, index) => {
      const requiredFields = ["name", "style", "primaryColor", "secondaryColor", "icon", "preview"];
      const missingFields = requiredFields.filter((field) => !logo[field]);
      if (missingFields.length > 0) {
        throw new Error(`Logo ${index + 1}: champs manquants: ${missingFields.join(", ")}`);
      }
    });
    return parsed;
  } catch (error) {
    console.error("Erreur parsing logo response:", error);
    return {
      logos: generateDefaultLogos()
    };
  }
}
function generateDefaultLogos() {
  return [
    {
      id: 1,
      name: "LOGO",
      style: "modern",
      primaryColor: "#1E40AF",
      secondaryColor: "#DC2626",
      icon: "\u{1F680}",
      preview: "LO",
      description: "Design moderne \xE9pur\xE9",
      fontCategory: "sans-serif",
      layout: "horizontal"
    },
    {
      id: 2,
      name: "LOGO",
      style: "modern",
      primaryColor: "#DC2626",
      secondaryColor: "#1E40AF",
      icon: "\u26A1",
      preview: "LOG",
      description: "Design dynamique et moderne",
      fontCategory: "display",
      layout: "vertical"
    },
    {
      id: 3,
      name: "LOGO",
      style: "classic",
      primaryColor: "#1E40AF",
      secondaryColor: "#FFFFFF",
      icon: "\u{1F3C6}",
      preview: "L",
      description: "Design classique \xE9l\xE9gant",
      fontCategory: "serif",
      layout: "emblem"
    },
    {
      id: 4,
      name: "LOGO",
      style: "tech",
      primaryColor: "#DC2626",
      secondaryColor: "#000000",
      icon: "\u{1F48E}",
      preview: "LO",
      description: "Design technologique innovant",
      fontCategory: "sans-serif",
      layout: "combination"
    }
  ];
}
