"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var push_send_exports = {};
__export(push_send_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(push_send_exports);
var import_supabase_js = require("@supabase/supabase-js");
var import_web_push = __toESM(require("web-push"), 1);
const supabaseUrl = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY;
const VAPID_PUBLIC = process.env.VAPID_PUBLIC_KEY || process.env.VITE_VAPID_PUBLIC_KEY;
const VAPID_PRIVATE = process.env.VAPID_PRIVATE_KEY;
const VAPID_SUBJECT = process.env.VAPID_SUBJECT || "mailto:contact@abawi.com";
if (VAPID_PUBLIC && VAPID_PRIVATE) {
  import_web_push.default.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC, VAPID_PRIVATE);
}
const handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };
  }
  if (!VAPID_PUBLIC || !VAPID_PRIVATE) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: "VAPID keys not configured" }) };
  }
  try {
    const { membreId, title, body, url, icon, badge, tag, data } = JSON.parse(event.body || "{}");
    if (!membreId || !title) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: "membreId and title required" }) };
    }
    const supabase = (0, import_supabase_js.createClient)(supabaseUrl, supabaseKey);
    const { data: subs } = await supabase.from("push_subscriptions").select("*").eq("membre_id", membreId);
    if (!subs || subs.length === 0) {
      return { statusCode: 200, headers, body: JSON.stringify({ ok: true, sent: 0, reason: "no subscriptions" }) };
    }
    const payload = JSON.stringify({
      title,
      body: body || "",
      url: url || "/abavie",
      icon: icon || "/icons/icon-192.png",
      badge: badge || "/icons/icon-72.png",
      tag: tag || "abavie-message",
      data: data || {}
    });
    const results = await Promise.allSettled(
      subs.map((s) => {
        const sub = {
          endpoint: s.endpoint,
          keys: { p256dh: s.p256dh, auth: s.auth }
        };
        return import_web_push.default.sendNotification(sub, payload).catch(async (err) => {
          if (err.statusCode === 404 || err.statusCode === 410) {
            await supabase.from("push_subscriptions").delete().eq("endpoint", s.endpoint);
          }
          throw err;
        });
      })
    );
    const sent = results.filter((r) => r.status === "fulfilled").length;
    const failed = results.filter((r) => r.status === "rejected").length;
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ ok: true, sent, failed, total: subs.length })
    };
  } catch (e) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: e.message }) };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
